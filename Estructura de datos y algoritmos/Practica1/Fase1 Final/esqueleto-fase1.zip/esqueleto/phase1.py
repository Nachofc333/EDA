from slist import SList
import sys

class SList2(SList):

    def sumLastN(self, n):
        ...
    
    #method for inserting a new node in the middle
    def insertMiddle(self, elem):
        
        ...

    
    def insertList(self,inputList,start,end):
        ...


    def reverseK(self,k):
        ...


    def maximumPair(self):
        ...
 