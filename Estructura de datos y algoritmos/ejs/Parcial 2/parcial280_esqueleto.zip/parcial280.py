# -*- coding: utf-8 -*-
"""
Created on Thu Apr 28 18:20:30 2022

@author: ishernanz
"""

import random
from bst import BinarySearchTree
from bintree import BinaryTree

class MyBST(BinarySearchTree):
    
    def get_odd_siblings(self):
        
        ...
        